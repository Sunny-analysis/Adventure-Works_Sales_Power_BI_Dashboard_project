SELECT 
  C.CustomerKey AS CustomerKey, 
  --,[GeographyKey]
  -- ,[CustomerAlternateKey]
  -- ,[Title]
  [FirstName] AS FirstName, 
  --,[MiddleName]
  [LastName] AS LastName, 
  c.firstname + ' ' + c.lastname AS FullName, 
  -- ,[NameStyle]
  -- ,[BirthDate]
  --,[MaritalStatus]
  --,[Suffix]
  Case [Gender] when 'M' Then 'Male' when 'F' then 'Female' End As Gender, 
  -- ,[EmailAddress]
  -- ,[YearlyIncome]
  -- ,[TotalChildren]
  --,[NumberChildrenAtHome]
  -- ,[EnglishEducation]
  --,[SpanishEducation]
  --,[FrenchEducation]
  --,[EnglishOccupation]
  --,[SpanishOccupation]
  --,[FrenchOccupation]
  --,[HouseOwnerFlag]
  --,[NumberCarsOwned]
  -- ,[AddressLine1]
  -- ,[AddressLine2]
  -- ,[Phone]
  [DateFirstPurchase], 
  --,[CommuteDistance]
  G.City AS CustomerCity -- Joined City Column from DimGeography Table
FROM 
  AdventureWorksDW2022.dbo.DimCustomer AS C 
  LEFT JOIN AdventureWorksDW2022.dbo.DimGeography AS G ON g.geographykey = c.geographykey 
ORDER BY 
  CustomerKey ASC -- Arranging order by customer Key