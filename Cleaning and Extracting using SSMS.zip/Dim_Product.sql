SELECT p.[ProductKey] AS Product_Key,
      p.[ProductAlternateKey] AS Porduct_Item_Code,
      --,[ProductSubcategoryKey]
      --,[WeightUnitMeasureCode]
      --,[SizeUnitMeasureCode]
      P.[EnglishProductName] AS Product_Name,
	  PS.[EnglishProductSubcategoryName] AS Product_Sub_Category,  -- Joined from Product Sub category Table
	  PC.[EnglishProductCategoryName] AS Product_Category,  -- Joined from Product Sub category Table
      --,[SpanishProductName]
      --,[FrenchProductName]
      --,[StandardCost]
      --,[FinishedGoodsFlag]
      P.[Color] As Product_Color,
      --,[SafetyStockLevel]
      --,[ReorderPoint]
      --,[ListPrice]
      P.[Size] AS Product_size,
      --,[SizeRange]
     -- ,[Weight]
     -- ,[DaysToManufacture]
      P.[ProductLine] AS Product_Line,
      --,[DealerPrice]
     -- ,[Class]
      --,[Style]
      P.[ModelName] AS Product_Model_Name,
      --,[LargePhoto]
      P.[EnglishDescription] AS Product_Derscription,
      --,[FrenchDescription]
      --,[ChineseDescription]
      --,[ArabicDescription]
      --,[HebrewDescription]
      --,[ThaiDescription]
      --,[GermanDescription]
      --,[JapaneseDescription]
      --,[TurkishDescription]
      --,[StartDate]
      --,[EndDate]+
  ISNULL (P.[Status], 'OutDated') As Product_Status 

  FROM
  [AdventureWorksDW2022].[dbo].[DimProduct] as P
  LEFT JOIN AdventureWorksDW2022.dbo.DimProductSubcategory AS PS ON PS.ProductSubcategoryKey = P.ProductSubcategoryKey
  LEFT JOIN AdventureWorksDW2022.dbo.DimProductcategory AS PC ON PS.ProductcategoryKey = PC.ProductCategoryKey
  ORDER BY
  P.ProductKey ASC
